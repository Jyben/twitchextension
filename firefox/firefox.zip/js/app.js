window.TwitchAlert = new TwitchAlert();

TwitchAlert.updateExtensionPage();